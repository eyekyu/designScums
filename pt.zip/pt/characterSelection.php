<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="test.css" />
<title>Test</title>
</head>

<body>
    <div id="content">
    <h1><p>Welcome</p></h1>
    
     <p>Hi There and Welcome to Zombie Fest</p>
    
    <p>This is a game decidated to zombie survival. We hoep you enjoy your gameplay.</p>
    
    <p>Instructions:</p>
        <ul>
            <li>Touch anywhere on the map to move</li>
            <li>Touch a coin to pick it up</li>
            <li>When Playing please rotate the device for better gameplay</li>
            <li>TO BE INTRODUCED</li>
        </ul>
    <p><input type="button" value="Game" onclick="location.href='http://webwaygate.com/ian/pt/game.php';"></p>
    </div>
    
    <div id="footer">
    </div>

</body>
</html>
