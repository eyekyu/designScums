<html><head>
	<script src="phaser.js"></script>
	<script src="game.js"></script>
</head>
<body></body></html>